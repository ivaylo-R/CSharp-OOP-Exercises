﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface IBirthdaytable
    {
        public DateTime Birthdate { get; }
    }
}
