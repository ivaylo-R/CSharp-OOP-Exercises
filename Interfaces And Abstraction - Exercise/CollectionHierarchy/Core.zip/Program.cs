﻿using CollectionHierarchy.Core;
using System;

namespace CollectionHierarchy
{
    public class Program
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
