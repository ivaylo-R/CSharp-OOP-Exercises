﻿namespace CollectionHierarchy.Interfaces
{
    public interface IUsed
    {
        public int Used { get; }
    }
}
