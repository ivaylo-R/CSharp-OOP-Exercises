﻿using System.Collections.Generic;

namespace CollectionHierarchy.Interfaces
{
    public interface IAdd
    {
        public void Add(string item);
    }
}
