﻿namespace MilitaryElite.Intefaces
{
    public interface ISpy : ISoldier
    {
        public int CodeNumber { get; }
    }
}
