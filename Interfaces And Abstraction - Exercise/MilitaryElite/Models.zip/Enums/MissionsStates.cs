﻿namespace MilitaryElite.Enums
{
    public enum MissionsStates
    {
        inProgress = 1,
        Finished = 2
    }
}
