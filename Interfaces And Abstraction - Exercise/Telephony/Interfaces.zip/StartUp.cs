﻿using System;
using Telephony.Core;

namespace Telephony
{
    public class StartUp
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
