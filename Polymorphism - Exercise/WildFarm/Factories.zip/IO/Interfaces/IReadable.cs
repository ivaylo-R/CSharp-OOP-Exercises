﻿namespace Raiding.IO.Interfaces
{
    public interface IReadable
    {
        string ReadLine();
    }
}
