﻿namespace WildFarm.Common
{
    public class ExceptionMessages
    {
        public static string INVALID_FOOD = "Invalid food";
    }
}
