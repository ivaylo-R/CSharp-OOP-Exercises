﻿namespace WildFarm.Models.Foods.Contracts
{
    public interface IFood
    {
        int Quantity { get; }
    }
}
