﻿namespace Vehicles.IO.Contracts
{
    public interface IReadable
    {
        string ReadLine();
    }
}
