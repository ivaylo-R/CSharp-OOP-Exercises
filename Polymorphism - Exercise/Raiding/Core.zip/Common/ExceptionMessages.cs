﻿namespace Raiding.Common
{
    public  class ExceptionMessages
    {
        public static string INV_HERO= "Invalid hero!";
    }
}
