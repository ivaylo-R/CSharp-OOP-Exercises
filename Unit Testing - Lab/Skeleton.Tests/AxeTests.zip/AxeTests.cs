using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using System;
using Assert = NUnit.Framework.Assert;

[TestFixture]
public class AxeTests
{


    [Test]
    public void CheckIfWeaponLosesDurabilityAfterEachAttack()
    {
        //Arrange
        Axe axe = new Axe(10, 10);
        Dummy dummy = new Dummy(100, 100);

        //Act

        axe.Attack(dummy);

        //Assert

        Assert.That(axe.DurabilityPoints, Is.EqualTo(9), "Axe durabillity doesnt change after attack");
    }

    [Test]
    public void TestAttackingWithABrokenWeapon()
    {
        //Arrange
        Axe axe= new Axe(10, 0);
        Dummy dummy = new Dummy(10, 10);

        //Act && Assert

        var ex = Assert.Throws<InvalidOperationException>(() => axe.Attack(dummy));
        Assert.That(ex.Message, Is.EqualTo("Axe is broken."));
    }

    

    


}