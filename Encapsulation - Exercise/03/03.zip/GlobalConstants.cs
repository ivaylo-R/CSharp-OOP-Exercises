﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03
{
    public static class GlobalConstants
    {
        public const string MONEY_EXC_MSG = "Money cannot be negative";
        public const string NAME_EXC_MSG = "Name cannot be empty";
        public const string CANT_AFFORD_EXC_MSG = "{0} can't afford {1}";
        public const string SUCCES_BOUGHT_PRODUCT = "{0} bought {1}";
    }
}
