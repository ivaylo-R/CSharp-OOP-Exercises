﻿using FootballTeamGenerator;
using System;

namespace _05
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            Engine eng = new Engine();
            eng.Run();
        }
    }
}
