﻿using System;

namespace _04.IO
{
    public class ConsoleReader
    {
        public string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}
