﻿using System;
namespace _04.IO
{
    public class ConsoleWriter
    {
        public void WriteLine(string msg)
        {
            Console.WriteLine(msg);
        }
    }
}
