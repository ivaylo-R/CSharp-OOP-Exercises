﻿using System;
using System.Collections.Generic;

namespace _04
{
    public class Program
    {
        static void Main()
        {
            Engine engine = new Engine();
            engine.Run();
        }
    }
}
